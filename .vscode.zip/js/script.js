// DOM Elements
const modeToggle = document.getElementById('modeToggle');
const navLinks = document.querySelectorAll('.nav-link');
const contentSections = document.querySelectorAll('.content-section');
const genreGrid = document.getElementById('genre-container');
const quizSection = document.getElementById('quiz-section');
const questionText = document.getElementById('question-text');
const optionsContainer = document.getElementById('options-container');
const currentQuestionSpan = document.getElementById('current-question');
const totalQuestionsSpan = document.getElementById('total-questions');
const prevQuestionBtn = document.getElementById('prev-question');
const nextQuestionBtn = document.getElementById('next-question');
const submitQuizBtn = document.getElementById('submit-quiz');
const resultsSection = document.getElementById('results-section');
const scorePercent = document.getElementById('score-percent');
const correctAnswersSpan = document.getElementById('correct-answers');
const totalAnswersSpan = document.getElementById('total-answers');
const diamondsEarnedSpan = document.getElementById('diamonds-earned');
const diamondsSpan = document.getElementById('diamonds');
const backToGenresBtn = document.getElementById('back-to-genres');
const retryQuizBtn = document.getElementById('retry-quiz');
const startDailyBtn = document.getElementById('start-daily');
const streakCountSpan = document.getElementById('streak-count');
const lastCompletedSpan = document.getElementById('last-completed');
const leaderboardTable = document.querySelector('#leaderboard-table tbody');
const startQuizBtn = document.getElementById('start-quiz');
const exitQuizBtn = document.getElementById('exit-quiz');
const useHintBtn = document.getElementById('useHint');

// API Categories
const API_CATEGORIES = {
  'general': { id: 9, name: 'General Knowledge', icon: 'fas fa-globe' },
  'science': { id: 17, name: 'Science & Nature', icon: 'fas fa-flask' },
  'history': { id: 23, name: 'History', icon: 'fas fa-landmark' },
  'geography': { id: 22, name: 'Geography', icon: 'fas fa-map' },
  'movies': { id: 11, name: 'Entertainment: Film', icon: 'fas fa-film' },
  'sports': { id: 21, name: 'Sports', icon: 'fas fa-running' },
  'music': { id: 12, name: 'Entertainment: Music', icon: 'fas fa-music' },
  'literature': { id: 10, name: 'Entertainment: Books', icon: 'fas fa-book' }
};

// App State
const AppState = {
  currentGenre: null,
  currentQuestions: [],
  userAnswers: [],
  currentQuestionIndex: 0,
  diamonds: 0,
  streak: 0,
  lastCompletedDate: null,
  leaderboard: [],
  questions: [],
  genres: [],
  customQuestions: []
};

// Initialize the application
async function init() {
  loadUserData();
  await loadQuestions();
  setupEventListeners();
  renderGenres();
  updateDiamondsDisplay();
  updateStreakDisplay();
  showSection('home-section');
  renderLeaderboard();

    useHintBtn.addEventListener('click', useHint);
}

// Load user data from localStorage
function loadUserData() {
  AppState.diamonds = parseInt(localStorage.getItem('diamonds')) || 0;
  AppState.streak = parseInt(localStorage.getItem('streak')) || 0;
  AppState.lastCompletedDate = localStorage.getItem('lastCompletedDate');
  AppState.leaderboard = JSON.parse(localStorage.getItem('leaderboard')) || [];
  AppState.questions = JSON.parse(localStorage.getItem('quizQuestions')) || [];
  AppState.genres = JSON.parse(localStorage.getItem('quizGenres')) || [];
}

// Save user data to localStorage
function saveUserData() {
  localStorage.setItem('diamonds', AppState.diamonds.toString());
  localStorage.setItem('streak', AppState.streak.toString());
  if (AppState.lastCompletedDate) {
    localStorage.setItem('lastCompletedDate', AppState.lastCompletedDate);
  }
  localStorage.setItem('leaderboard', JSON.stringify(AppState.leaderboard));
}

// ... Existing code ...

// Update renderGenres to use localStorage
function renderGenres() {
  genreGrid.innerHTML = '';
  
  // Render API categories
  for (const [genreId, category] of Object.entries(API_CATEGORIES)) {
    const genreCard = createGenreCard(category.icon, category.name, () => startQuiz(genreId));
    genreGrid.appendChild(genreCard);
  }
  
  // Render custom genres from localStorage
  const customGenres = JSON.parse(localStorage.getItem('quizGenres')) || [];
  customGenres.forEach(genre => {
    const genreCard = createGenreCard(genre.icon, genre.name, () => startCustomQuiz(genre.id));
    genreGrid.appendChild(genreCard);
  });
}

function createGenreCard(icon, name, clickHandler) {
  const genreCard = document.createElement('div');
  genreCard.className = 'genre-card';
  genreCard.innerHTML = `
    <i class="${icon}"></i>
    <h3>${name}</h3>
  `;
  genreCard.addEventListener('click', clickHandler);
  return genreCard;
}

// Update startCustomQuiz to use localStorage
function startCustomQuiz(genreId) {
  try {
    const genres = JSON.parse(localStorage.getItem('quizGenres')) || [];
    const genre = genres.find(g => g.id == genreId);
    
    if (!genre) throw new Error("Genre not found");
    
    AppState.currentGenre = { 
      id: genre.id,
      name: genre.name,
      icon: genre.icon,
      isCustom: true
    };
    
    showSection('quiz-section');
    document.getElementById('quiz-genre').textContent = genre.name;
    questionText.textContent = "Loading questions...";
    optionsContainer.innerHTML = '';
    
    // Get questions from localStorage
    const allQuestions = JSON.parse(localStorage.getItem('quizQuestions')) || [];
    const genreQuestions = allQuestions.filter(q => q.genreId == genreId);
    
    if (genreQuestions.length === 0) {
      throw new Error("No questions found for this genre");
    }
    
    // Select 10 random questions
    AppState.currentQuestions = selectRandomQuestions(genreQuestions, 10).map(q => ({
      question: q.text,
      correctAnswer: q.options[q.answer],
      options: shuffleArray([...q.options])
    }));
    
    AppState.currentQuestionIndex = 0;
    AppState.userAnswers = new Array(AppState.currentQuestions.length).fill(null);
    renderQuestion();
    
  } catch (error) {
    handleQuizError(error);
  }
}

// ... Rest of the code remains the same ...

// Load questions from API and localStorage
async function loadQuestions() {
  try {
    // Load custom questions from localStorage
    AppState.customQuestions = JSON.parse(localStorage.getItem('quizQuestions')) || [];
    
    // Initialize genres with default if empty
    if (AppState.genres.length === 0) {
      AppState.genres = [
        { id: 1, name: 'General Knowledge', icon: 'fas fa-brain', description: 'Various topics from general knowledge' }
      ];
      localStorage.setItem('quizGenres', JSON.stringify(AppState.genres));
    }
  } catch (error) {
    console.error('Error loading questions:', error);
  }
}

// Render genre cards
function renderGenres() {
  genreGrid.innerHTML = '';
  
  // Render API categories
  for (const [genreId, category] of Object.entries(API_CATEGORIES)) {
    const genreCard = document.createElement('div');
    genreCard.className = 'genre-card';
    genreCard.innerHTML = `
      <i class="${category.icon}"></i>
      <h3>${category.name}</h3>
    `;
    genreCard.addEventListener('click', () => startQuiz(genreId));
    genreGrid.appendChild(genreCard);
  }
  
  // Render custom genres
  AppState.genres.forEach(genre => {
    const genreCard = document.createElement('div');
    genreCard.className = 'genre-card';
    genreCard.innerHTML = `
      <i class="${genre.icon || 'fas fa-question'}"></i>
      <h3>${genre.name}</h3>
    `;
    genreCard.addEventListener('click', () => startCustomQuiz(genre.id));
    genreGrid.appendChild(genreCard);
  });
}
// Update handleQuestionSubmit
function handleQuestionSubmit(e) {
  e.preventDefault();
  
  const genreId = parseInt(document.getElementById('question-genre').value);
  const difficulty = document.getElementById('question-difficulty').value;
  const text = document.getElementById('admin-question-text').value.trim();
  
  const optionInputs = document.querySelectorAll('.option-input');
  const options = Array.from(optionInputs).map(input => input.value.trim());
  
  const correctAnswerIndex = parseInt(
    document.querySelector('input[name="correct-answer"]:checked').value
  );
  
  // Validate inputs
  if (!genreId || !text || options.some(opt => !opt) || isNaN(correctAnswerIndex)) {
    alert('Please fill all fields and select correct answer!');
    return;
  }
  
  const questions = JSON.parse(localStorage.getItem('quizQuestions')) || [];
  
  const newQuestion = {
    id: Date.now(),
    genreId,
    difficulty,
    text,
    options,
    answer: correctAnswerIndex
  };
  
  questions.push(newQuestion);
  localStorage.setItem('quizQuestions', JSON.stringify(questions));
  
  alert('Question added successfully!');
  document.getElementById('question-form').reset();
  renderQuestionsList();
}

// Start quiz for a specific genre
async function startQuiz(genreId) {
    const { value: playerName } = await Swal.fire({
    title: 'Enter Your Name',
    input: 'text',
    inputPlaceholder: 'e.g. QuizMaster',
    allowOutsideClick: false,
    showCancelButton: false,
    inputValidator: (value) => {
      if (!value) return 'You need a name to play!';
    }
  });
  try {
    const genre = API_CATEGORIES[genreId];
    if (!genre) throw new Error("Invalid genre selected");
    
    AppState.currentPlayer = playerName;

    AppState.currentGenre = { 
      id: genre.id,
      name: genre.name,
      icon: genre.icon,
      isCustom: false
    };
    
    showSection('quiz-section');
    document.getElementById('quiz-genre').textContent = genre.name;
    questionText.textContent = "Loading questions...";
    optionsContainer.innerHTML = '';
    
    // Fetch questions from Open Trivia DB API
    fetch(`https://opentdb.com/api.php?amount=10&category=${genre.id}&type=multiple`)
      .then(response => response.json())
      .then(data => {
        if (!data.results || data.results.length === 0) throw new Error("No questions received from API");
        
        AppState.currentQuestions = data.results.map(q => ({
          question: decodeHTML(q.question),
          correctAnswer: decodeHTML(q.correct_answer),
          options: shuffleArray([...q.incorrect_answers.map(decodeHTML), decodeHTML(q.correct_answer)])
        }));
        
        AppState.currentQuestionIndex = 0;
        AppState.userAnswers = new Array(AppState.currentQuestions.length).fill(null);
        renderQuestion();
      })
      .catch(error => handleQuizError(error));
  } catch (error) {
    handleQuizError(error);
  }
}
async function registerUser(username, password) {
  try {
    const res = await fetch('/PRATIK/php/register.php', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({username, password})
    });
    const data = await res.json();
    if (data.success) {
      console.log('User registered successfully');
    } else {
      console.error('Register error:', data.error);
    }
  } catch (err) {
    console.error('Network error:', err);
  }
}

function useHint() {
  if (AppState.diamonds < 100) return;

  const currentQuestion = AppState.currentQuestions[AppState.currentQuestionIndex];
  const options = Array.from(document.querySelectorAll('.option-btn'));
  
  // Filter out correct answer and selected option (if any)
  const incorrectOptions = options.filter(option => 
    option.textContent !== currentQuestion.correctAnswer && 
    !option.classList.contains('selected')
  );

  // Remove two random incorrect options
  if (incorrectOptions.length >= 2) {
    const shuffled = [...incorrectOptions].sort(() => 0.5 - Math.random());
    shuffled.slice(0, 2).forEach(option => {
      option.style.opacity = '0.3';
      option.style.pointerEvents = 'none';
      option.disabled = true;
    });

    // Deduct diamonds
    AppState.diamonds -= 100;
    updateDiamondsDisplay();
    useHintBtn.disabled = true;
    
    // Visual feedback
    Swal.fire({
      icon: 'success',
      title: 'Hint Used!',
      text: 'Two wrong options removed',
      timer: 1500,
      showConfirmButton: false
    });
  }
}
// Start custom quiz
function startCustomQuiz(genreId) {
  try {
    const genre = AppState.genres.find(g => g.id == genreId);
    if (!genre) throw new Error("Genre not found");
    
    AppState.currentGenre = { 
      id: genre.id,
      name: genre.name,
      icon: genre.icon,
      isCustom: true
    };
    
    showSection('quiz-section');
    document.getElementById('quiz-genre').textContent = genre.name;
    questionText.textContent = "Loading questions...";
    optionsContainer.innerHTML = '';
    
    // Get questions for this genre
    const genreQuestions = AppState.questions.filter(q => q.genreId == genreId);
    if (genreQuestions.length === 0) {
      throw new Error("No questions found for this genre");
    }
    
    // Select 10 random questions
    AppState.currentQuestions = selectRandomQuestions(genreQuestions, 10).map(q => ({
      question: q.text,
      correctAnswer: q.options[q.answer],
      options: shuffleArray([...q.options])
    }));
    
    AppState.currentQuestionIndex = 0;
    AppState.userAnswers = new Array(AppState.currentQuestions.length).fill(null);
    renderQuestion();
    
  } catch (error) {
    handleQuizError(error);
  }
}

// Handle quiz errors
function handleQuizError(error) {
  console.error("Quiz error:", error);
  questionText.textContent = "⚠️ " + error.message;
  optionsContainer.innerHTML = '<button class="start-btn" onclick="showSection(\'genres-section\')">Back to Genres</button>';
}

// Render current question
function renderQuestion() {
  const question = AppState.currentQuestions[AppState.currentQuestionIndex];
  if (!question) return;

  // Update question text and clear options
  questionText.textContent = question.question;
  optionsContainer.innerHTML = '';

   useHintBtn.disabled = AppState.diamonds < 100 || 
                       AppState.currentQuestionIndex >= AppState.currentQuestions.length;
  
  // Reset all options to active
  document.querySelectorAll('.option-btn').forEach(option => {
    option.style.opacity = '1';
    option.style.pointerEvents = 'auto';
    option.disabled = false;
  });

  // Create and render option buttons
  question.options.forEach((option, index) => {
    const optionBtn = document.createElement('button');
    optionBtn.className = 'option-btn';
    optionBtn.textContent = option;
    
    // Add click event to select answer
    optionBtn.addEventListener('click', function() {
      // Remove selected class from all options
      document.querySelectorAll('.option-btn').forEach(btn => {
        btn.classList.remove('selected');
      });
      
      // Add selected class to clicked option
      this.classList.add('selected');
      
      // Save the answer
      AppState.userAnswers[AppState.currentQuestionIndex] = option;
    });
    
    optionsContainer.appendChild(optionBtn);
  });

  // Update navigation state
  updateQuizNavigation();
}

// Update quiz navigation buttons
function updateQuizNavigation() {
  currentQuestionSpan.textContent = AppState.currentQuestionIndex + 1;
  totalQuestionsSpan.textContent = AppState.currentQuestions.length;
  
  // Update navigation button states
  prevQuestionBtn.disabled = AppState.currentQuestionIndex === 0;
  nextQuestionBtn.disabled = AppState.currentQuestionIndex === AppState.currentQuestions.length - 1;
}

// Navigate to previous question
function prevQuestion() {
  if (AppState.currentQuestionIndex > 0) {
    AppState.currentQuestionIndex--;
    renderQuestion();
  }
}

// Navigate to next question
function nextQuestion() {
  if (AppState.currentQuestionIndex < AppState.currentQuestions.length - 1) {
    AppState.currentQuestionIndex++;
    renderQuestion();
  } else {
    submitQuiz();
  }
}

// Submit quiz and show results
async function submitQuiz() {
  // Calculate score
  const correctAnswers = AppState.currentQuestions.reduce((count, question, index) => {
    return count + (question.correctAnswer === AppState.userAnswers[index] ? 1 : 0);
  }, 0);

  const totalQuestions = AppState.currentQuestions.length;
  const diamondsEarned = correctAnswers * 10;

  // Ask for player name
  const { value: playerName } = await Swal.fire({
    title: 'Save Your Score',
    input: 'text',
    inputPlaceholder: 'Enter your name',
    showCancelButton: false,
    allowOutsideClick: false,
    inputValidator: (value) => value ? null : 'Name is required!'
  });

  if (!playerName) {
    return; // Exit if no name entered
  }

  // Prepare data to save
  const payload = {
    username: playerName,
    score: correctAnswers,
    diamonds: diamondsEarned,
    date: new Date().toISOString()
  };

  // Save to localStorage
  saveResult(playerName, correctAnswers, diamondsEarned);
  
  // Update UI
  updateResultsDisplay(correctAnswers, totalQuestions, diamondsEarned);
  showSection('results-section');
}

function updateResultsDisplay(correct, total, diamonds) {
  scorePercent.textContent = `${Math.round((correct/total)*100)}%`;
  correctAnswersSpan.textContent = correct;
  totalAnswersSpan.textContent = total;
  diamondsEarnedSpan.textContent = diamonds;
  AppState.diamonds += diamonds;
  updateDiamondsDisplay();
}

// Helper functions
function generateScoreStars(percentage) {
  const stars = Math.ceil(percentage / 20);
  return '★'.repeat(stars) + '☆'.repeat(5 - stars);
}

function getScoreMessage(percentage) {
  if (percentage >= 90) return 'Quiz Master!';
  if (percentage >= 70) return 'Great job!';
  if (percentage >= 50) return 'Good effort!';
  return 'Keep practicing!';
}
// Update streak
function updateStreak() {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const todayStr = today.toISOString().split('T')[0];
  
  if (!AppState.lastCompletedDate) {
    AppState.streak = 1;
  } else {
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    const yesterdayStr = yesterday.toISOString().split('T')[0];
    
    if (AppState.lastCompletedDate === yesterdayStr) {
      AppState.streak++;
    } else if (AppState.lastCompletedDate < yesterdayStr) {
      AppState.streak = 1;
    }
  }
  
  AppState.lastCompletedDate = todayStr;
  updateStreakDisplay();
}

// Update streak display
function updateStreakDisplay() {
  streakCountSpan.textContent = AppState.streak;
  lastCompletedSpan.textContent = AppState.lastCompletedDate || 'Never';
}

// Update diamonds display
function updateDiamondsDisplay() {
  diamondsSpan.textContent = AppState.diamonds;
}

// Render leaderboard from localStorage
function renderLeaderboard() {
  const leaderboard = JSON.parse(localStorage.getItem('leaderboard')) || [];
  const tbody = document.querySelector('#leaderboard-table tbody');
  tbody.innerHTML = '';
  
  if (!leaderboard || leaderboard.length === 0) {
    const row = document.createElement('tr');
    row.innerHTML = `<td colspan="4">No scores yet. Be the first!</td>`;
    tbody.appendChild(row);
    return;
  }
  
  // Sort by score descending
  leaderboard.sort((a, b) => b.score - a.score);
  
  leaderboard.slice(0, 10).forEach((entry, index) => {
    const row = document.createElement('tr');
    row.innerHTML = `
      <td>${index + 1}</td>
      <td>${entry.username}</td>
      <td>${entry.score}</td>
      <td>${entry.diamonds}</td>
    `;
    tbody.appendChild(row);
  });
}

// Save result to localStorage
function saveResult(username, score, diamonds) {
  const leaderboard = JSON.parse(localStorage.getItem('leaderboard')) || [];
  
  // Add new entry
  leaderboard.push({
    username,
    score,
    diamonds,
    date: new Date().toISOString()
  });
  
  // Save back to localStorage
  localStorage.setItem('leaderboard', JSON.stringify(leaderboard));
  
  // Update UI
  renderLeaderboard();
}


// Show a specific section
function showSection(sectionId) {
  contentSections.forEach(section => {
    section.classList.remove('active-section');
  });
  document.getElementById(sectionId).classList.add('active-section');
}

// Helper function to decode HTML entities
function decodeHTML(html) {
  const txt = document.createElement('textarea');
  txt.innerHTML = html;
  return txt.value;
}

// Helper function to shuffle array
function shuffleArray(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
  return array;
}

// Select random questions
function selectRandomQuestions(questions, count) {
  const shuffled = shuffleArray([...questions]);
  return shuffled.slice(0, Math.min(count, shuffled.length));
}

// Setup event listeners
function setupEventListeners() {
  // Navigation
  navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
      if (link.dataset.section) {
        e.preventDefault();
        showSection(link.dataset.section);
      }
    });
  });

  // Quiz navigation
  prevQuestionBtn.addEventListener('click', prevQuestion);
  nextQuestionBtn.addEventListener('click', nextQuestion);
  submitQuizBtn.addEventListener('click', submitQuiz);
  
  // Results navigation
  backToGenresBtn.addEventListener('click', () => showSection('genres-section'));
  retryQuizBtn.addEventListener('click', () => {
    if (AppState.currentGenre.isCustom) {
      startCustomQuiz(AppState.currentGenre.id);
    } else {
      startQuiz(Object.keys(API_CATEGORIES).find(key => 
        API_CATEGORIES[key].id === AppState.currentGenre.id
      ));
    }
  });
  
  // Daily challenge
  startDailyBtn.addEventListener('click', startDailyChallenge);
  
  // Dark mode toggle
  modeToggle.addEventListener('click', () => {
    document.body.classList.toggle('light-mode');
    localStorage.setItem('lightMode', document.body.classList.contains('light-mode'));
    modeToggle.textContent = document.body.classList.contains('light-mode') ? '🌙' : '☀️';
  });
  
  // Start quiz button
  startQuizBtn.addEventListener('click', () => {
    showSection('genres-section');
  });
  
  // Exit quiz button
  exitQuizBtn.addEventListener('click', () => {
    showSection('genres-section');
  });
}

// Start daily challenge
function startDailyChallenge() {
  const genreKeys = Object.keys(API_CATEGORIES);
  const randomGenreKey = genreKeys[Math.floor(Math.random() * genreKeys.length)];
  startQuiz(randomGenreKey);
}

// Initialize the app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  // Check for saved theme preference
  if (localStorage.getItem('lightMode') === 'true') {
    document.body.classList.add('light-mode');
    modeToggle.textContent = '🌙';
  }
  // Music Control
// Music Control
// Music Player Functionality
const musicToggle = document.getElementById('musicToggle');
const bgMusic = document.getElementById('bgMusic');
const musicStatus = document.getElementById('musicStatus');

function safeJSON(response) {
  return response.text().then(text => {
    try {
      return JSON.parse(text);
    } catch (err) {
      console.error("Invalid JSON from server:", text);
      throw err;
    }
  });
}

// Initialize music state
function initMusicPlayer() {
  // Load saved preference or default to off
  const musicOn = localStorage.getItem('musicEnabled') === 'true';
  
  // Set initial state
  if (musicOn) {
    bgMusic.volume = 0.3; // Lower volume
    enableMusic();
  }
  
  // Click handler
  musicToggle.addEventListener('click', toggleMusic);
  
  // Handle browser autoplay policies
  document.addEventListener('click', () => {
    if (localStorage.getItem('musicEnabled') === 'true' && bgMusic.paused) {
      bgMusic.play().catch(e => console.log("Autoplay blocked:", e));
    }
  }, { once: true });
}

function toggleMusic() {
  if (bgMusic.paused) {
    enableMusic();
  } else {
    disableMusic();
  }
}

function enableMusic() {
  bgMusic.play()
    .then(() => {
      musicStatus.textContent = 'ON';
      localStorage.setItem('musicEnabled', 'true');
    })
    .catch(e => {
      console.log("Music play failed:", e);
      musicStatus.textContent = 'OFF';
    });
}

function disableMusic() {
  bgMusic.pause();
  musicStatus.textContent = 'OFF';
  localStorage.setItem('musicEnabled', 'false');
}

// Initialize when app starts
initMusicPlayer();
  
  init();
});