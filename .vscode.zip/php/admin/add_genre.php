<?php
require_once __DIR__ . '/../config.php';  // Correct path to config.php
header('Content-Type: application/json');

// Get JSON input sent from JS
$data = json_decode(file_get_contents('php://input'), true);
$genre_name = $data['name'] ?? '';

if (!$genre_name) {
    echo json_encode(['error' => 'Genre name is required']);
    exit;
}

try {
    // Use $pdo from config.php
    $stmt = $pdo->prepare("INSERT INTO genres (name) VALUES (:name)");
    $stmt->execute(['name' => $genre_name]);
    echo json_encode(['success' => true, 'message' => 'Genre added successfully']);
} catch (PDOException $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
