<?php
require_once __DIR__ . '/../config.php';



header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);

$genreId = $data['genreId'];
$difficulty = $data['difficulty'];
$text = $data['text'];
$options = $data['options'];
$answer = $data['answer'] + 1; // Convert to 1-indexed

$stmt = $conn->prepare("INSERT INTO questions 
    (genre_id, difficulty, text, option1, option2, option3, option4, answer) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("issssssi",
    $genreId,
    $difficulty,
    $text,
    $options[0],
    $options[1],
    $options[2],
    $options[3],
    $answer
);
$stmt->execute();
$questionId = $stmt->insert_id;
$stmt->close();

echo json_encode(['success' => true, 'id' => $questionId]);
?>