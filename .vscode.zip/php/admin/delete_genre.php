<?php
require_once __DIR__ . '/../config.php';


header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);
$id = $data['id'];

// Delete related questions first
$stmt = $conn->prepare("DELETE FROM questions WHERE genre_id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$stmt->close();

// Then delete genre
$stmt = $conn->prepare("DELETE FROM genres WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$stmt->close();

echo json_encode(['success' => true]);
?>