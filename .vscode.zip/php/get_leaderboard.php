<?php
header('Content-Type: application/json');
require_once __DIR__ . '/config.php';

try {
    $stmt = $pdo->query("
        SELECT users.username, leaderboard.score 
        FROM leaderboard 
        JOIN users ON leaderboard.user_id = users.id 
        ORDER BY leaderboard.score DESC 
        LIMIT 10
    ");
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode($data);
    exit;
} catch (PDOException $e) {
    echo json_encode(['error' => $e->getMessage()]);
    exit;
}
