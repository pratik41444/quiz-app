<?php
header('Content-Type: application/json');
require_once __DIR__ . '/config.php';

$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['username']) || !isset($data['score'])) {
    echo json_encode(['error' => 'Missing username or score']);
    exit;
}

$username = $data['username'];
$score = (int)$data['score'];


try {
    // Find user ID from username
    $stmt = $pdo->prepare('SELECT id FROM users WHERE username = ?');
    $stmt->execute([$username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        echo json_encode(['error' => 'User not found']);
        exit;
    }

    $userId = $user['id'];

    // Insert the score into leaderboard
    $insert = $pdo->prepare('INSERT INTO leaderboard (user_id, score) VALUES (?, ?)');
    $insert->execute([$userId, $score]);

    echo json_encode(['success' => true, 'message' => 'Result saved']);
} catch (PDOException $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
